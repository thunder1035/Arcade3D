# HUD Map [hud_map]

HUD Notify is a mod that can be used display messages using HUD elements (instead of chat) for better noticeability. Due to the higher potential for abuse, the use of this command is restricted to moderators and above.

### Dependencies: None

### Usage

- `/notify <player_name> <msg>`

### minetest.conf

- `hud_notify.hud_duration`
  - Stores a numeric value (10 by default) which represents the duration of the message visibility in seconds.

### Screenshot

![screenshot](map)

### TODO

- Add automatic line-break if `msg` too long.
