give_initial_stuff=true

minetest.register_on_newplayer(function(player)
	local inv=player:get_inventory()
	inv:add_item("main","ghost:Blinky 20")
	inv:add_item("main","ghost:Pinky 20")
	inv:add_item("main","ghost:Inky 20")
	inv:add_item("main","ghost:Clyed 20")
	inv:add_item("main","maze:pacman_maze")
	if minetest.check_player_privs(player:get_player_name(), {server=true}) then
		inv:add_ndoe("main","images:display_demo")
	end
end)
