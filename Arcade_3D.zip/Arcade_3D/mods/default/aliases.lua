-- mods/default/aliases.lua

-- Aliases to support loading worlds using nodes following the old naming convention
-- These can also be helpful when using chat commands, for example /giveme
minetest.register_alias("stono", "basic:stono")
minetest.register_alias("gate", "basic:gate")

