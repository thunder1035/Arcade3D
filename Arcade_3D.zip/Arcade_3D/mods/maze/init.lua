---------mts_placing---------------
------minetest.place_schematic-------

minetest.register_craftitem("maze:pacman_maze", {
	description = "spawner of pacman_maze",
	inventory_image = "icon_maze.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("maze").."/schemes/maze.we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.x = p.x - 5
			p.z = p.z - 2
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})
