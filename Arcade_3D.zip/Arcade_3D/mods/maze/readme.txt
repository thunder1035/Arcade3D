this spawns the maze in new world
