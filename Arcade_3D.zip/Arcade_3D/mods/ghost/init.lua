----BLINKY---
mobs:register_mob("ghost:Blinky", {
type = "monster",
	hp_max = 5,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.8, 0.4},
	stepheight = 0,
	visual = "upright_sprite",
	textures = {"Blinky_front.png", "Blinky_back.png"},
	visual_size = {x=2, y=2},
	view_range = 10000,
	walk_velocity = 2,
	run_velocity = 2,
	damage = 10,
	drops = {},
	armor = 200,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 1,
	light_damage = 0,
                  jump = false,
                  suffocation = 2,
	reach = 1,
                  fear_height = 10,
	walk_chance = 100,
	stand_chance = 0,
	attack_chance = 5,
                  blood_amount = 0,
                  randomly_turn = true,
                  passive = false,
                  group_attack = false,
	attack_type = "dogfight",
})
mobs:register_spawn("ghost:Blinky", {"basic:spawn"}, 20, -1, 14000, 1, -64)

mobs:register_egg("ghost:Blinky", "Blinky", "Blinky_back.png", 3)

----PINKY---
mobs:register_mob("ghost:Pinky", {
type = "monster",
	hp_max = 2,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.8, 0.4},
	stepheight = 0,
	visual = "upright_sprite",
	textures = {"Pinky_front.png", "Pinky_back.png"},
	visual_size = {x=2, y=2},
	view_range = 10000,
	walk_velocity = 2,
	run_velocity = 2,
	damage = 10,
	drops = {},
	armor = 200,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 1,
	light_damage = 0,
                  jump = false,
                  suffocation = 2,
	reach = 1,
                  fear_height = 10,
	walk_chance = 100,
	stand_chance = 0,
	attack_chance = 5,
                  blood_amount = 0,
                  randomly_turn = true,
                  passive = false,
                  group_attack = false,
	attack_type = "dogfight",
})
mobs:register_spawn("ghost:Pinky", {"basic:spawn"}, 20, -1, 14000, 1, -64)

mobs:register_egg("ghost:Pinky", "Pinky", "Pinky_back.png", 3)

-------------INKY--------------------------------------
mobs:register_mob("ghost:Inky", {
	type = "monster",
	hp_max = 2,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.8, 0.4},
	stepheight = 0,
	visual = "upright_sprite",
	textures = {"Inky_front.png", "Inky_back.png"},
	visual_size = {x=2, y=2},
	view_range = 10000,
	walk_velocity = 2,
	run_velocity = 2,
	damage = 10,
	drops = {},
	armor = 200,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 1,
	light_damage = 0,
                  jump = false,
                  suffocation = 2,
	reach = 1,
                  fear_height = 10,
	walk_chance = 100,
	stand_chance = 0,
	attack_chance = 5,
                  blood_amount = 0,
                  randomly_turn = true,
                  passive = false,
                  group_attack = false,
	attack_type = "dogfight",
})
mobs:register_spawn("ghost:Inky", {"basic:spawn"}, 20, -1, 14000, 1, -64)

mobs:register_egg("ghost:Inky", "Inky", "Inky_back.png", 3)

---------CLYDE------------------------------
mobs:register_mob("ghost:Clyed", {
	type = "monster",
	hp_max = 2,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.8, 0.4},
	stepheight = 0,
	visual = "upright_sprite",
	textures = {"Clyde_front.png", "Clyde_back.png"},
	visual_size = {x=2, y=2},
	view_range = 10000,
	walk_velocity = 2,
	run_velocity = 2,
	damage = 10,
	drops = {},
	armor = 200,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 1,
	light_damage = 0,
                  jump = false,
                  suffocation = 2,
	reach = 1,
                  fear_height = 10,
	walk_chance = 100,
	stand_chance = 0,
	attack_chance = 5,
                  blood_amount = 0,
                  randomly_turn = true,
                  passive = false,
                  group_attack = false,
	attack_type = "dogfight",
})
mobs:register_spawn("ghost:Clyed", {"basic:spawn"}, 20, -1, 14000, 1, -64)

mobs:register_egg("ghost:Clyed", "Clyed", "Clyde_back.png", 3)

---------------------------testing---------------------------
mobs:register_mob("ghost:scared", {
	type = "animal",
	hp_max = 2,
	sounds = {},
	lifetimer = 120, -- 2 minutes
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.8, 0.4},
	stepheight = 1.1,
	visual = "upright_sprite",
	textures = {"scared_front.png", "scared_back.png"},
	visual_size = {x=2, y=2},
	view_range = 1000,
	walk_velocity = 1,
	run_velocity = 3,
	damage = 1,
	drops = {},
	armor = 100,
	drawtype = "front",
	water_damage = 1,
	lava_damage = 1,
	light_damage = 0,
	runaway_from = "player",
	attack_type = "dogfight",
})

mobs:register_spawn("ghost:scared", {"basic:spawn"}, 20, -1, 14000, 1, -64)

mobs:register_egg("ghost:scared", "scared", "scared_back.png", 3)
