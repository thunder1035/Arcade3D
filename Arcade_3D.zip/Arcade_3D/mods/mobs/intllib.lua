-- Support for the old multi-load method
return dofile(minetest.get_modpath("intllib").."/init.lua")

